# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(ErlangHotpatch src/ErlangHotpatch.cpp)
set_property(TARGET ErlangHotpatch PROPERTY CXX_STANDARD 11)
target_link_libraries(ErlangHotpatch lionss pthread)

add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(glossary-check src/glossary-check.cpp)
set_property(TARGET glossary-check PROPERTY CXX_STANDARD 11)
target_link_libraries(glossary-check lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(NavMeshBake src/NavMeshBake.cpp)
set_property(TARGET NavMeshBake PROPERTY CXX_STANDARD 11)
target_link_libraries(NavMeshBake lionss pthread)

add_executable(marmot src/marmot.cpp)
set_property(TARGET marmot PROPERTY CXX_STANDARD 11)
target_link_libraries(marmot lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(NimbusRelay src/NimbusRelay.cpp)
set_property(TARGET NimbusRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(NimbusRelay lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(sgd-nesterov src/sgd-nesterov.cpp)
set_property(TARGET sgd-nesterov PROPERTY CXX_STANDARD 11)
target_link_libraries(sgd-nesterov lionss pthread)

add_executable(tile_z14 src/tile_z14.cpp)
set_property(TARGET tile_z14 PROPERTY CXX_STANDARD 11)
target_link_libraries(tile_z14 lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(kotlin-inline src/kotlin-inline.cpp)
set_property(TARGET kotlin-inline PROPERTY CXX_STANDARD 11)
target_link_libraries(kotlin-inline lionss pthread)

add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

add_executable(SeccompFilter src/SeccompFilter.cpp)
set_property(TARGET SeccompFilter PROPERTY CXX_STANDARD 11)
target_link_libraries(SeccompFilter lionss pthread)

add_executable(relooperCfg src/relooperCfg.cpp)
set_property(TARGET relooperCfg PROPERTY CXX_STANDARD 11)
target_link_libraries(relooperCfg lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(Quillon src/Quillon.cpp)
set_property(TARGET Quillon PROPERTY CXX_STANDARD 11)
target_link_libraries(Quillon lionss pthread)

add_executable(tlsResume src/tlsResume.cpp)
set_property(TARGET tlsResume PROPERTY CXX_STANDARD 11)
target_link_libraries(tlsResume lionss pthread)

add_executable(zerolog src/zerolog.cpp)
set_property(TARGET zerolog PROPERTY CXX_STANDARD 11)
target_link_libraries(zerolog lionss pthread)

add_executable(recordReplay src/recordReplay.cpp)
set_property(TARGET recordReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(recordReplay lionss pthread)

add_executable(tonemap_aces src/tonemap_aces.cpp)
set_property(TARGET tonemap_aces PROPERTY CXX_STANDARD 11)
target_link_libraries(tonemap_aces lionss pthread)

add_executable(zonemapskip src/zonemapskip.cpp)
set_property(TARGET zonemapskip PROPERTY CXX_STANDARD 11)
target_link_libraries(zonemapskip lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(lut-grade src/lut-grade.cpp)
set_property(TARGET lut-grade PROPERTY CXX_STANDARD 11)
target_link_libraries(lut-grade lionss pthread)

