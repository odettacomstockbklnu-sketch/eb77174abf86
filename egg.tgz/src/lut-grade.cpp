// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply 3D LUT"); }
int main(){
  announce();
  return lionss_run_workload("lut-grade");
}
