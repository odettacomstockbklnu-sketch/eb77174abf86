// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Forward relay traffic"); }
int main(){
  announce();
  return lionss_run_workload("NimbusRelay");
}
